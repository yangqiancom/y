<?php
// Define some constants 
define("RECIPIENT_NAME", "Your Name"); //Set here your Name
define("RECIPIENT_EMAIL", "yourmail@mail.com"); // Set Here your email adresse
define("EMAIL_SUBJECT", "Your email subject"); // Set here email subject
?>